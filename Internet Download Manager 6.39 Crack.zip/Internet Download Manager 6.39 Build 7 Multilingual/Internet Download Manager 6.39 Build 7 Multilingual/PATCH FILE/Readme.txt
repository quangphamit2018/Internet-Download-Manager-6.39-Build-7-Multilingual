Copy patch to installation folder & run it
 